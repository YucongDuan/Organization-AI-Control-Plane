package controlplane

default allow = false

allow if {
  input.action == "role.switch"
  some next
  next := input.next_role
  allowed := data.policy.roles.allowed_switches[input.current_role]
  next == allowed[_]
}

needs_approval if {
  input.action == "memory.write"
  input.scope == "long_term"
}

needs_approval if {
  input.action == "memory.write"
  input.scope == "protected"
}
