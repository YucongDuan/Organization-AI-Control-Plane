from __future__ import annotations
from pathlib import Path
import sys
import os

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

tmp_dir = ROOT / ".test_runtime"
tmp_dir.mkdir(parents=True, exist_ok=True)
os.environ["CONTROL_PLANE_DB"] = str(tmp_dir / "control_plane.db")
os.environ["CONTROL_PLANE_ARTIFACT_ROOT"] = str(tmp_dir / "artifacts")
os.environ["CONTROL_PLANE_POLICY"] = str(ROOT / "configs" / "policy_bundle.yaml")
os.environ["CONTROL_PLANE_BACKENDS"] = str(ROOT / "configs" / "backends.yaml")

from fastapi.testclient import TestClient
from src.control_plane.app import app
from src.control_plane.db import init_db

client = TestClient(app)

def setup_module():
    db_path = tmp_dir / "control_plane.db"
    if db_path.exists():
        db_path.unlink()
    init_db()


def _bootstrap():
    identity = client.post("/v1/identities", json={
        "persona_id": "tester",
        "invariant_rules": ["No silent memory write"],
        "source_ref": "unit_test"
    }).json()
    session = client.post("/v1/sessions", json={
        "system_id": identity["system_id"],
        "role_id": "planner"
    }).json()
    run = client.post("/v1/runs", json={
        "session_id": session["session_id"],
        "task_type": "cn_long_document",
        "risk_level": "medium",
        "sovereignty_required": True
    }).json()
    return identity, session, run

def test_full_lifecycle():
    _, _, run = _bootstrap()
    client.post(f"/v1/runs/{run['run_id']}/evidence", json={
        "source": "docset",
        "locator": "s3://bucket/doc1",
        "note": "unit"
    })
    sw1 = client.post(f"/v1/runs/{run['run_id']}/role-switch", json={
        "next_role": "reasoner",
        "actor": "op1",
        "reason": "decomposed"
    })
    assert sw1.status_code == 200
    req = client.post(f"/v1/runs/{run['run_id']}/memory-write", json={
        "scope": "long_term",
        "content": "alpha",
        "source": "unit",
        "sensitivity": "low",
        "proposer": "reasoner"
    }).json()
    approval_id = req["approval"]["request_id"]
    dec = client.post(f"/v1/approvals/{approval_id}/decision", json={
        "actor": "op1",
        "actor_role": "auditor",
        "decision": "approved"
    })
    assert dec.status_code == 200
    sw2 = client.post(f"/v1/runs/{run['run_id']}/role-switch", json={
        "next_role": "auditor",
        "actor": "op1",
        "reason": "audit"
    })
    assert sw2.status_code == 200
    fin = client.post(f"/v1/runs/{run['run_id']}/finalize", json={
        "actor": "op1",
        "output_text": "safe internal output",
        "output_summary": "done",
        "public_shell": "internal"
    })
    assert fin.status_code == 200
    report = fin.json()
    assert report["approvals"]
    whitebox = client.get(f"/v1/runs/{run['run_id']}/whitebox")
    assert whitebox.status_code == 200
