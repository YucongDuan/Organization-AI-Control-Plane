from __future__ import annotations
from pathlib import Path
import sys
import os

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

tmp_dir = ROOT / ".test_runtime"
tmp_dir.mkdir(parents=True, exist_ok=True)
os.environ["CONTROL_PLANE_DB"] = str(tmp_dir / "control_plane.db")
os.environ["CONTROL_PLANE_ARTIFACT_ROOT"] = str(tmp_dir / "artifacts")
os.environ["CONTROL_PLANE_POLICY"] = str(ROOT / "configs" / "policy_bundle.yaml")
os.environ["CONTROL_PLANE_BACKENDS"] = str(ROOT / "configs" / "backends.yaml")

from fastapi.testclient import TestClient
from src.control_plane.app import app
from src.control_plane.db import init_db

client = TestClient(app)

def setup_module():
    db_path = tmp_dir / "control_plane.db"
    if db_path.exists():
        db_path.unlink()
    init_db()


def _bootstrap():
    identity = client.post("/v1/identities", json={
        "persona_id": "tester",
        "invariant_rules": ["No role escalation without approval"],
        "source_ref": "unit_test"
    }).json()
    session = client.post("/v1/sessions", json={
        "system_id": identity["system_id"],
        "role_id": "planner"
    }).json()
    run = client.post("/v1/runs", json={
        "session_id": session["session_id"],
        "task_type": "general_task",
        "risk_level": "medium",
        "sovereignty_required": False
    }).json()
    return run

def test_unauthorized_switch_blocked():
    run = _bootstrap()
    resp = client.post(f"/v1/runs/{run['run_id']}/role-switch", json={
        "next_role": "auditor",
        "actor": "op1",
        "reason": "skip reasoner"
    })
    assert resp.status_code == 403

def test_finalize_without_evidence_blocked():
    run = _bootstrap()
    client.post(f"/v1/runs/{run['run_id']}/role-switch", json={
        "next_role": "reasoner",
        "actor": "op1",
        "reason": "normal"
    })
    client.post(f"/v1/runs/{run['run_id']}/role-switch", json={
        "next_role": "auditor",
        "actor": "op1",
        "reason": "normal"
    })
    resp = client.post(f"/v1/runs/{run['run_id']}/finalize", json={
        "actor": "op1",
        "output_text": "no evidence output",
        "output_summary": "done",
        "public_shell": "internal"
    })
    assert resp.status_code == 403
