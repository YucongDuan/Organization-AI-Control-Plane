from __future__ import annotations
from .repositories import Repo
from .policy import PolicyEngine
from .router import BackendRouter
from .whitebox import build_report, export_replay_bundle

repo = Repo()
policy = PolicyEngine()
router = BackendRouter()

def verify_invariants(identity: dict, candidate_output: str) -> list[str]:
    violations = []
    for rule in identity["invariant_rules"]:
        marker = f"VIOLATE::{rule}"
        if marker in candidate_output:
            violations.append(rule)
    return violations

def choose_backend(task_type: str, risk_level: str, sovereignty_required: bool) -> dict:
    return router.choose(task_type=task_type, risk_level=risk_level, sovereignty_required=sovereignty_required)

def request_memory_write(run_id: str, scope: str, content: str, source: str, sensitivity: str, proposer: str):
    decision = policy.evaluate("memory.write", {"scope": scope})
    payload = {"scope": scope, "content": content, "source": source, "sensitivity": sensitivity}
    if not decision.required_approval:
        item = repo.create_memory(run_id, scope, content, source, sensitivity)
        repo.add_event(run_id, "memory.write", {"memory_id": item["memory_id"], "scope": scope, "source": source, "path": "direct"})
        return {"mode": "direct", "memory": item, "policy": decision.model_dump()}
    approval = repo.create_approval(
        run_id=run_id,
        object_type="memory_item",
        before={},
        after=payload,
        rationale="memory write request",
        risk_level="high" if sensitivity == "high" else "medium",
        proposer=proposer,
    )
    repo.add_event(run_id, "memory.write.requested", {"request_id": approval["request_id"], "scope": scope, "source": source})
    return {"mode": "approval", "approval": approval, "policy": decision.model_dump()}

def decide_approval(request_id: str, actor: str, actor_role: str, decision_text: str):
    decision = policy.evaluate("approval.decide", {"actor_role": actor_role})
    if not decision.allow:
        raise PermissionError("; ".join(decision.reasons))
    approval = repo.decide_approval(request_id, approver=actor, decision=decision_text)
    memory = None
    if approval["object_type"] == "memory_item" and decision_text == "approved":
        memory = repo.approve_memory_from_request(request_id, approver=actor)
        repo.add_event(approval["run_id"], "memory.write.approved", {"request_id": request_id, "memory_id": memory["memory_id"], "actor": actor})
    return approval, memory

def role_switch(run_id: str, next_role: str, actor: str, reason: str):
    run = repo.get_run(run_id)
    session = repo.get_session(run["session_id"])
    decision = policy.evaluate("role.switch", {"current_role": session["active_role"], "next_role": next_role})
    if not decision.allow:
        raise PermissionError("; ".join(decision.reasons))
    current = session["active_role"]
    session = repo.update_session_role(run["session_id"], next_role)
    repo.add_role_transition(run_id, current, next_role, reason, actor)
    repo.add_event(run_id, "role.switch", {"from": current, "to": next_role, "actor": actor, "reason": reason})
    return session, decision

def finalize_run(run_id: str, actor: str, output_text: str, output_summary: str, public_shell: str):
    run = repo.get_run(run_id)
    session = repo.get_session(run["session_id"])
    identity = repo.get_identity(session["system_id"])
    evidence = repo.list_evidence(run_id)
    memories = repo.list_memories(run_id)
    events = repo.list_events(run_id)
    approvals = repo.list_approvals_for_run(run_id)
    gate = policy.evaluate("run.finalize", {"evidence_count": len(evidence), "output_text": output_text, "public_shell": public_shell})
    if not gate.allow:
        raise PermissionError("; ".join(gate.reasons))
    invariant_violations = verify_invariants(identity, output_text)
    backend_decision = {
        "backend_id": run["backend_id"],
        "risk_level": run["risk_level"],
        "sovereignty_required": run["sovereignty_required"],
        "router_summary": "backend chosen by local router",
    }
    report = build_report(run, session, evidence, approvals, memories, events, output_text, backend_decision, invariant_violations)
    replay_pointer = export_replay_bundle(run_id, report, {"actor": actor, "output_summary": output_summary}, output_text, evidence, approvals, memories, events)
    repo.save_whitebox(run_id, report)
    repo.finalize_run(run_id, output_hash=report["output_hash"], replay_pointer=replay_pointer)
    repo.add_event(run_id, "run.finalized", {"actor": actor, "output_hash": report["output_hash"]})
    return repo.get_whitebox(run_id)
