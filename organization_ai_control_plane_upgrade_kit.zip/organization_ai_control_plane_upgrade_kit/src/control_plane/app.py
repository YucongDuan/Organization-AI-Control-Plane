from __future__ import annotations
from contextlib import asynccontextmanager
from fastapi import FastAPI, HTTPException
from .db import init_db
from .models import (
    IdentityCreate, IdentityOut, SessionCreate, SessionOut, RunCreate, RunOut,
    RoleSwitchRequest, EvidenceCreate, EvidenceOut, MemoryWriteRequest,
    ApprovalDecisionRequest, ApprovalOut, FinalizeRunRequest
)
from .repositories import Repo
from .services import choose_backend, request_memory_write, decide_approval, role_switch, finalize_run

@asynccontextmanager
async def lifespan(app: FastAPI):
    init_db()
    yield

app = FastAPI(title="Organization AI Control Plane", version="0.2.0", lifespan=lifespan)
repo = Repo()

@app.get("/healthz")
def healthz():
    return {"ok": True}

@app.post("/v1/identities", response_model=IdentityOut)
def create_identity(payload: IdentityCreate):
    return repo.create_identity(payload.persona_id, payload.invariant_rules, payload.source_ref)

@app.post("/v1/sessions", response_model=SessionOut)
def create_session(payload: SessionCreate):
    try:
        repo.get_identity(payload.system_id)
    except KeyError:
        raise HTTPException(404, "identity not found")
    return repo.create_session(payload.system_id, payload.role_id, payload.policy_version)

@app.post("/v1/runs", response_model=RunOut)
def create_run(payload: RunCreate):
    try:
        repo.get_session(payload.session_id)
    except KeyError:
        raise HTTPException(404, "session not found")
    backend = choose_backend(payload.task_type, payload.risk_level, payload.sovereignty_required)
    run = repo.create_run(
        session_id=payload.session_id,
        tenant_id=payload.tenant_id,
        task_type=payload.task_type,
        risk_level=payload.risk_level,
        backend_id=backend["backend_id"],
        sovereignty_required=payload.sovereignty_required,
    )
    repo.add_event(run["run_id"], "run.created", {"backend": backend, "task_type": payload.task_type, "risk_level": payload.risk_level})
    return run

@app.get("/v1/runs/{run_id}", response_model=RunOut)
def get_run(run_id: str):
    try:
        return repo.get_run(run_id)
    except KeyError:
        raise HTTPException(404, "run not found")

@app.post("/v1/runs/{run_id}/evidence", response_model=EvidenceOut)
def add_evidence(run_id: str, payload: EvidenceCreate):
    try:
        repo.get_run(run_id)
    except KeyError:
        raise HTTPException(404, "run not found")
    evidence = repo.add_evidence(run_id, payload.source, payload.locator, payload.note, payload.content_hash)
    repo.add_event(run_id, "evidence.added", {"evidence_id": evidence["evidence_id"], "source": payload.source})
    return evidence

@app.post("/v1/runs/{run_id}/memory-write")
def create_memory_request(run_id: str, payload: MemoryWriteRequest):
    try:
        repo.get_run(run_id)
    except KeyError:
        raise HTTPException(404, "run not found")
    return request_memory_write(run_id, payload.scope, payload.content, payload.source, payload.sensitivity, payload.proposer)

@app.post("/v1/runs/{run_id}/role-switch")
def switch_role(run_id: str, payload: RoleSwitchRequest):
    try:
        session, decision = role_switch(run_id, payload.next_role, payload.actor, payload.reason)
        return {"session": session, "policy": decision.model_dump()}
    except KeyError:
        raise HTTPException(404, "run not found")
    except PermissionError as exc:
        raise HTTPException(403, str(exc))

@app.post("/v1/approvals/{request_id}/decision", response_model=ApprovalOut)
def approval_decision(request_id: str, payload: ApprovalDecisionRequest):
    try:
        approval, _memory = decide_approval(request_id, payload.actor, payload.actor_role, payload.decision)
        return {
            "request_id": approval["request_id"],
            "run_id": approval["run_id"],
            "object_type": approval["object_type"],
            "decision": approval["decision"],
            "risk_level": approval["risk_level"],
            "proposer": approval["proposer"],
            "approver": approval["approver"],
            "created_at": approval["created_at"],
            "decided_at": approval["decided_at"],
        }
    except KeyError:
        raise HTTPException(404, "approval not found")
    except PermissionError as exc:
        raise HTTPException(403, str(exc))

@app.post("/v1/runs/{run_id}/finalize")
def finalize(run_id: str, payload: FinalizeRunRequest):
    try:
        report = finalize_run(run_id, payload.actor, payload.output_text, payload.output_summary, payload.public_shell)
        return report
    except KeyError:
        raise HTTPException(404, "run not found")
    except PermissionError as exc:
        raise HTTPException(403, str(exc))

@app.get("/v1/runs/{run_id}/whitebox")
def get_whitebox(run_id: str):
    try:
        return repo.get_whitebox(run_id)
    except KeyError:
        raise HTTPException(404, "whitebox not found")
