from __future__ import annotations
from dataclasses import dataclass
from .db import get_conn
from .utils import dumps, loads, new_id, utc_now

@dataclass
class Repo:
    def create_identity(self, persona_id: str, invariant_rules: list[str], source_ref: str):
        system_id = new_id("system")
        chain_id = new_id("chain")
        created_at = utc_now()
        with get_conn() as conn:
            conn.execute(
                "INSERT INTO identities(system_id, persona_id, invariant_rules_json, continuity_chain_id, created_at, source_ref) VALUES (?,?,?,?,?,?)",
                (system_id, persona_id, dumps(invariant_rules), chain_id, created_at, source_ref),
            )
        return {
            "system_id": system_id,
            "persona_id": persona_id,
            "invariant_rules": invariant_rules,
            "continuity_chain_id": chain_id,
            "created_at": created_at,
            "source_ref": source_ref,
        }

    def get_identity(self, system_id: str):
        with get_conn() as conn:
            row = conn.execute("SELECT * FROM identities WHERE system_id=?", (system_id,)).fetchone()
        if not row:
            raise KeyError(system_id)
        return {
            "system_id": row["system_id"],
            "persona_id": row["persona_id"],
            "invariant_rules": loads(row["invariant_rules_json"]),
            "continuity_chain_id": row["continuity_chain_id"],
            "created_at": row["created_at"],
            "source_ref": row["source_ref"],
        }

    def create_session(self, system_id: str, role_id: str, policy_version: str):
        session_id = new_id("session")
        created_at = utc_now()
        role_history = [role_id]
        with get_conn() as conn:
            conn.execute(
                "INSERT INTO sessions(session_id, system_id, active_role, role_history_json, policy_version, created_at) VALUES (?,?,?,?,?,?)",
                (session_id, system_id, role_id, dumps(role_history), policy_version, created_at),
            )
        return {
            "session_id": session_id,
            "system_id": system_id,
            "active_role": role_id,
            "role_history": role_history,
            "policy_version": policy_version,
            "created_at": created_at,
        }

    def get_session(self, session_id: str):
        with get_conn() as conn:
            row = conn.execute("SELECT * FROM sessions WHERE session_id=?", (session_id,)).fetchone()
        if not row:
            raise KeyError(session_id)
        return {
            "session_id": row["session_id"],
            "system_id": row["system_id"],
            "active_role": row["active_role"],
            "role_history": loads(row["role_history_json"]),
            "policy_version": row["policy_version"],
            "created_at": row["created_at"],
        }

    def update_session_role(self, session_id: str, next_role: str):
        session = self.get_session(session_id)
        session["active_role"] = next_role
        session["role_history"].append(next_role)
        with get_conn() as conn:
            conn.execute(
                "UPDATE sessions SET active_role=?, role_history_json=? WHERE session_id=?",
                (next_role, dumps(session["role_history"]), session_id),
            )
        return session

    def create_run(self, session_id: str, tenant_id: str, task_type: str, risk_level: str, backend_id: str, sovereignty_required: bool):
        run_id = new_id("run")
        created_at = utc_now()
        with get_conn() as conn:
            conn.execute(
                "INSERT INTO runs(run_id, session_id, tenant_id, task_type, risk_level, backend_id, sovereignty_required, status, created_at) VALUES (?,?,?,?,?,?,?,?,?)",
                (run_id, session_id, tenant_id, task_type, risk_level, backend_id, int(sovereignty_required), "running", created_at),
            )
        return self.get_run(run_id)

    def get_run(self, run_id: str):
        with get_conn() as conn:
            row = conn.execute("SELECT * FROM runs WHERE run_id=?", (run_id,)).fetchone()
        if not row:
            raise KeyError(run_id)
        return {
            "run_id": row["run_id"],
            "session_id": row["session_id"],
            "tenant_id": row["tenant_id"],
            "task_type": row["task_type"],
            "risk_level": row["risk_level"],
            "backend_id": row["backend_id"],
            "sovereignty_required": bool(row["sovereignty_required"]),
            "status": row["status"],
            "created_at": row["created_at"],
            "finalized_at": row["finalized_at"],
            "output_hash": row["output_hash"],
            "replay_pointer": row["replay_pointer"],
        }

    def finalize_run(self, run_id: str, output_hash: str, replay_pointer: str):
        finalized_at = utc_now()
        with get_conn() as conn:
            conn.execute(
                "UPDATE runs SET status=?, finalized_at=?, output_hash=?, replay_pointer=? WHERE run_id=?",
                ("finalized", finalized_at, output_hash, replay_pointer, run_id),
            )
        return self.get_run(run_id)

    def add_evidence(self, run_id: str, source: str, locator: str, note: str, content_hash: str | None):
        evidence_id = new_id("evd")
        created_at = utc_now()
        with get_conn() as conn:
            conn.execute(
                "INSERT INTO evidence(evidence_id, run_id, source, locator, note, content_hash, created_at) VALUES (?,?,?,?,?,?,?)",
                (evidence_id, run_id, source, locator, note, content_hash, created_at),
            )
        return {
            "evidence_id": evidence_id,
            "source": source,
            "locator": locator,
            "note": note,
            "content_hash": content_hash,
            "created_at": created_at,
        }

    def list_evidence(self, run_id: str):
        with get_conn() as conn:
            rows = conn.execute("SELECT * FROM evidence WHERE run_id=? ORDER BY created_at", (run_id,)).fetchall()
        return [
            {
                "evidence_id": row["evidence_id"],
                "source": row["source"],
                "locator": row["locator"],
                "note": row["note"],
                "content_hash": row["content_hash"],
                "created_at": row["created_at"],
            }
            for row in rows
        ]

    def create_approval(self, run_id: str, object_type: str, before: dict, after: dict, rationale: str, risk_level: str, proposer: str):
        request_id = new_id("apr")
        created_at = utc_now()
        with get_conn() as conn:
            conn.execute(
                "INSERT INTO approvals(request_id, run_id, object_type, before_json, after_json, rationale, risk_level, proposer, approver, decision, created_at, decided_at) VALUES (?,?,?,?,?,?,?,?,?,?,?,?)",
                (request_id, run_id, object_type, dumps(before), dumps(after), rationale, risk_level, proposer, None, "pending", created_at, None),
            )
        return self.get_approval(request_id)

    def get_approval(self, request_id: str):
        with get_conn() as conn:
            row = conn.execute("SELECT * FROM approvals WHERE request_id=?", (request_id,)).fetchone()
        if not row:
            raise KeyError(request_id)
        return {
            "request_id": row["request_id"],
            "run_id": row["run_id"],
            "object_type": row["object_type"],
            "before": loads(row["before_json"]),
            "after": loads(row["after_json"]),
            "rationale": row["rationale"],
            "risk_level": row["risk_level"],
            "proposer": row["proposer"],
            "approver": row["approver"],
            "decision": row["decision"],
            "created_at": row["created_at"],
            "decided_at": row["decided_at"],
        }

    def decide_approval(self, request_id: str, approver: str, decision: str):
        decided_at = utc_now()
        with get_conn() as conn:
            conn.execute(
                "UPDATE approvals SET approver=?, decision=?, decided_at=? WHERE request_id=?",
                (approver, decision, decided_at, request_id),
            )
        return self.get_approval(request_id)

    def create_memory(self, run_id: str, scope: str, content: str, source: str, sensitivity: str):
        memory_id = new_id("mem")
        created_at = utc_now()
        with get_conn() as conn:
            conn.execute(
                "INSERT INTO memories(memory_id, run_id, scope, content, source, sensitivity, status, version, approved_by, approved_at, created_at) VALUES (?,?,?,?,?,?,?,?,?,?,?)",
                (memory_id, run_id, scope, content, source, sensitivity, "approved", 1, None, None, created_at),
            )
        return self.get_memory(memory_id)

    def approve_memory_from_request(self, request_id: str, approver: str):
        approval = self.get_approval(request_id)
        after = approval["after"]
        memory_id = new_id("mem")
        approved_at = utc_now()
        with get_conn() as conn:
            conn.execute(
                "INSERT INTO memories(memory_id, run_id, scope, content, source, sensitivity, status, version, approved_by, approved_at, created_at) VALUES (?,?,?,?,?,?,?,?,?,?,?)",
                (memory_id, approval["run_id"], after["scope"], after["content"], after["source"], after["sensitivity"], "approved", 1, approver, approved_at, approved_at),
            )
        return self.get_memory(memory_id)

    def get_memory(self, memory_id: str):
        with get_conn() as conn:
            row = conn.execute("SELECT * FROM memories WHERE memory_id=?", (memory_id,)).fetchone()
        if not row:
            raise KeyError(memory_id)
        return dict(row)

    def list_memories(self, run_id: str):
        with get_conn() as conn:
            rows = conn.execute("SELECT * FROM memories WHERE run_id=? ORDER BY created_at", (run_id,)).fetchall()
        return [dict(row) for row in rows]

    def add_role_transition(self, run_id: str, from_role: str, to_role: str, reason: str, actor: str):
        created_at = utc_now()
        with get_conn() as conn:
            conn.execute(
                "INSERT INTO role_transitions(run_id, from_role, to_role, reason, actor, created_at) VALUES (?,?,?,?,?,?)",
                (run_id, from_role, to_role, reason, actor, created_at),
            )

    def list_role_transitions(self, run_id: str):
        with get_conn() as conn:
            rows = conn.execute("SELECT * FROM role_transitions WHERE run_id=? ORDER BY id", (run_id,)).fetchall()
        return [dict(row) for row in rows]

    def add_event(self, run_id: str, event_type: str, payload: dict):
        event_id = new_id("evt")
        created_at = utc_now()
        with get_conn() as conn:
            conn.execute(
                "INSERT INTO events(event_id, run_id, event_type, payload_json, created_at) VALUES (?,?,?,?,?)",
                (event_id, run_id, event_type, dumps(payload), created_at),
            )

    def list_events(self, run_id: str):
        with get_conn() as conn:
            rows = conn.execute("SELECT * FROM events WHERE run_id=? ORDER BY created_at", (run_id,)).fetchall()
        return [
            {
                "event_id": row["event_id"],
                "run_id": row["run_id"],
                "event_type": row["event_type"],
                "payload": loads(row["payload_json"]),
                "created_at": row["created_at"],
            }
            for row in rows
        ]

    def list_approvals_for_run(self, run_id: str):
        with get_conn() as conn:
            rows = conn.execute("SELECT request_id FROM approvals WHERE run_id=? ORDER BY created_at", (run_id,)).fetchall()
        return [self.get_approval(r["request_id"]) for r in rows]

    def save_whitebox(self, run_id: str, report: dict):
        created_at = utc_now()
        with get_conn() as conn:
            conn.execute(
                "INSERT OR REPLACE INTO whitebox_reports(run_id, report_json, created_at) VALUES (?,?,?)",
                (run_id, dumps(report), created_at),
            )

    def get_whitebox(self, run_id: str):
        with get_conn() as conn:
            row = conn.execute("SELECT * FROM whitebox_reports WHERE run_id=?", (run_id,)).fetchone()
        if not row:
            raise KeyError(run_id)
        return loads(row["report_json"])
