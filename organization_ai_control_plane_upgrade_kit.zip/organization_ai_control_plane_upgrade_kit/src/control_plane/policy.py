from __future__ import annotations
from pathlib import Path
import json
import urllib.request
import yaml
from .config import POLICY_PATH, OPA_URL, OPA_PACKAGE
from .models import PolicyDecision

class PolicyEngine:
    def __init__(self, path: Path | None = None) -> None:
        self.bundle = yaml.safe_load((path or POLICY_PATH).read_text(encoding="utf-8"))

    def evaluate(self, action: str, context: dict) -> PolicyDecision:
        if OPA_URL:
            try:
                return self._evaluate_remote(action, context)
            except Exception as exc:
                return PolicyDecision(allow=False, reasons=[f"OPA unavailable: {exc}"], required_approval=False, source="opa")
        return self._evaluate_local(action, context)

    def _evaluate_remote(self, action: str, context: dict) -> PolicyDecision:
        url = f"{OPA_URL}/v1/data/{OPA_PACKAGE}/allow"
        payload = json.dumps({"input": {"action": action, **context}}).encode("utf-8")
        req = urllib.request.Request(url, data=payload, method="POST", headers={"Content-Type": "application/json"})
        with urllib.request.urlopen(req, timeout=3) as resp:
            result = json.loads(resp.read().decode("utf-8"))
        allow = bool(result.get("result", False))
        return PolicyDecision(allow=allow, reasons=["OPA decision"], source="opa")

    def _evaluate_local(self, action: str, context: dict) -> PolicyDecision:
        reasons: list[str] = []
        required_approval = False
        allow = True

        if action == "role.switch":
            current = context["current_role"]
            next_role = context["next_role"]
            allowed_switches = self.bundle["roles"]["allowed_switches"]
            if next_role not in allowed_switches.get(current, []):
                allow = False
                reasons.append(f"role switch {current}->{next_role} not allowed")
        elif action == "memory.write":
            scope = context["scope"]
            if scope in self.bundle["memory"]["approval_required_scopes"]:
                required_approval = True
                reasons.append(f"{scope} requires approval")
        elif action == "approval.decide":
            actor_role = context["actor_role"]
            approver_roles = set(self.bundle["roles"]["approver_roles"])
            if actor_role not in approver_roles:
                allow = False
                reasons.append(f"role {actor_role} cannot approve")
        elif action == "run.finalize":
            if self.bundle.get("required_evidence_for_finalize", True) and context.get("evidence_count", 0) <= 0:
                allow = False
                reasons.append("cannot finalize without evidence")
            output_text = context.get("output_text", "")
            public_shell = context.get("public_shell", "internal")
            if public_shell == "public":
                blocked = [term for term in self.bundle.get("blocked_terms", []) if term in output_text]
                if blocked:
                    allow = False
                    reasons.append(f"blocked public claims: {blocked}")
        return PolicyDecision(allow=allow, reasons=reasons, required_approval=required_approval, source="local")
