from __future__ import annotations
from .config import ARTIFACT_ROOT
from .utils import stable_hash, utc_now
import json

def build_report(run: dict, session: dict, evidence: list[dict], approvals: list[dict], memories: list[dict], events: list[dict], output_text: str, backend_decision: dict, invariant_violations: list[str]):
    output_hash = stable_hash(output_text)
    replay_pointer = f"replay://{run['run_id']}/{output_hash[:12]}"
    report = {
        "run_id": run["run_id"],
        "task_type": run["task_type"],
        "tenant_id": run["tenant_id"],
        "backend_used": run["backend_id"],
        "role_path": session["role_history"],
        "evidence_refs": [{"source": e["source"], "locator": e["locator"], "note": e["note"]} for e in evidence],
        "approvals": [a["request_id"] for a in approvals if a["decision"] != "pending"],
        "memory_ids": [m["memory_id"] for m in memories],
        "output_hash": output_hash,
        "replay_pointer": replay_pointer,
        "policy_version": session["policy_version"],
        "invariant_violations": invariant_violations,
        "backend_decision": backend_decision,
        "created_at": utc_now(),
    }
    return report

def export_replay_bundle(run_id: str, report: dict, input_payload: dict, output_text: str, evidence: list[dict], approvals: list[dict], memories: list[dict], events: list[dict]) -> str:
    run_dir = ARTIFACT_ROOT / "replays" / run_id
    run_dir.mkdir(parents=True, exist_ok=True)
    (run_dir / "input.json").write_text(json.dumps(input_payload, ensure_ascii=False, indent=2), encoding="utf-8")
    (run_dir / "output.txt").write_text(output_text, encoding="utf-8")
    (run_dir / "whitebox_report.json").write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding="utf-8")
    (run_dir / "evidence.json").write_text(json.dumps(evidence, ensure_ascii=False, indent=2), encoding="utf-8")
    (run_dir / "approvals.json").write_text(json.dumps(approvals, ensure_ascii=False, indent=2), encoding="utf-8")
    (run_dir / "memories.json").write_text(json.dumps(memories, ensure_ascii=False, indent=2), encoding="utf-8")
    (run_dir / "events.json").write_text(json.dumps(events, ensure_ascii=False, indent=2), encoding="utf-8")
    return f"replay://{run_id}/{report['output_hash'][:12]}"
