from __future__ import annotations
from pathlib import Path
import os

ROOT = Path(__file__).resolve().parents[2]

def _default(name: str, rel: str) -> str:
    return os.getenv(name, str(ROOT / rel))

DB_PATH = Path(_default("CONTROL_PLANE_DB", "data/control_plane.db"))
POLICY_PATH = Path(_default("CONTROL_PLANE_POLICY", "configs/policy_bundle.yaml"))
BACKENDS_PATH = Path(_default("CONTROL_PLANE_BACKENDS", "configs/backends.yaml"))
ARTIFACT_ROOT = Path(_default("CONTROL_PLANE_ARTIFACT_ROOT", "artifacts"))
OPA_URL = os.getenv("OPA_URL", "").strip()
OPA_PACKAGE = os.getenv("OPA_PACKAGE", "controlplane").strip()

DB_PATH.parent.mkdir(parents=True, exist_ok=True)
ARTIFACT_ROOT.mkdir(parents=True, exist_ok=True)
