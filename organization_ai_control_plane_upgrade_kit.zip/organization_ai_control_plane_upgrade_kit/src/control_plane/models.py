from __future__ import annotations
from typing import Any, Literal, Optional
from pydantic import BaseModel, Field

class IdentityCreate(BaseModel):
    persona_id: str
    invariant_rules: list[str]
    source_ref: str = "manual"

class IdentityOut(BaseModel):
    system_id: str
    persona_id: str
    invariant_rules: list[str]
    continuity_chain_id: str
    created_at: str
    source_ref: str

class SessionCreate(BaseModel):
    system_id: str
    role_id: str
    policy_version: str = "v1"

class SessionOut(BaseModel):
    session_id: str
    system_id: str
    active_role: str
    role_history: list[str]
    policy_version: str
    created_at: str

class RunCreate(BaseModel):
    session_id: str
    tenant_id: str = "default"
    task_type: str
    risk_level: Literal["low", "medium", "high"] = "medium"
    sovereignty_required: bool = False

class RunOut(BaseModel):
    run_id: str
    session_id: str
    tenant_id: str
    task_type: str
    risk_level: str
    backend_id: str
    sovereignty_required: bool
    status: str
    created_at: str
    finalized_at: Optional[str] = None

class RoleSwitchRequest(BaseModel):
    next_role: str
    actor: str
    reason: str

class EvidenceCreate(BaseModel):
    source: str
    locator: str
    note: str = ""
    content_hash: str | None = None

class EvidenceOut(BaseModel):
    evidence_id: str
    source: str
    locator: str
    note: str
    content_hash: str | None
    created_at: str

class MemoryWriteRequest(BaseModel):
    scope: Literal["session", "long_term", "protected"]
    content: str
    source: str
    sensitivity: Literal["low", "medium", "high"] = "medium"
    proposer: str

class ApprovalDecisionRequest(BaseModel):
    actor: str
    actor_role: str
    decision: Literal["approved", "rejected"]

class ApprovalOut(BaseModel):
    request_id: str
    run_id: str
    object_type: str
    decision: str
    risk_level: str
    proposer: str
    approver: Optional[str]
    created_at: str
    decided_at: Optional[str]

class FinalizeRunRequest(BaseModel):
    actor: str
    output_text: str
    output_summary: str = ""
    public_shell: str = "internal"

class WhiteboxReport(BaseModel):
    run_id: str
    task_type: str
    tenant_id: str
    backend_used: str
    role_path: list[str]
    evidence_refs: list[dict[str, Any]]
    approvals: list[str]
    memory_ids: list[str]
    output_hash: str
    replay_pointer: str
    policy_version: str
    invariant_violations: list[str] = Field(default_factory=list)
    backend_decision: dict[str, Any] = Field(default_factory=dict)
    created_at: str

class PolicyDecision(BaseModel):
    allow: bool
    reasons: list[str] = Field(default_factory=list)
    required_approval: bool = False
    source: str = "local"
