from __future__ import annotations
from pathlib import Path
import yaml
from .config import BACKENDS_PATH

class BackendRouter:
    def __init__(self, path: Path | None = None) -> None:
        payload = yaml.safe_load((path or BACKENDS_PATH).read_text(encoding="utf-8"))
        self.backends = payload["backends"]

    def choose(self, task_type: str, risk_level: str, sovereignty_required: bool = False) -> dict:
        ordered = list(self.backends)
        if sovereignty_required:
            filtered = [b for b in ordered if b["sovereignty_level"] in {"regional", "private"}]
            if filtered:
                ordered = filtered
        if risk_level == "high":
            private_or_low = [b for b in ordered if b["max_risk"] == "low" or b["sovereignty_level"] == "private"]
            if private_or_low:
                ordered = private_or_low
        if task_type.startswith("cn_"):
            for preferred in ["qwen", "deepseek_v32", "private_open"]:
                match = next((b for b in ordered if b["backend_id"] == preferred), None)
                if match:
                    return match
        return ordered[0]
