# Organization AI Control Plane Upgrade Kit

This kit upgrades the minimal DIKWP runtime scaffold into a deployable local-first control plane and white-box audit runtime.

## What this kit is
- A **control plane / governance runtime** that sits above LLM backends.
- A **white-box audit layer** that records role switches, evidence refs, approvals, memory writes, and replay bundles.
- A **local-first** developer scaffold using FastAPI + SQLite, designed to be replaced with Postgres / object storage / OPA in production.

## What this kit is not
- Not a foundation model.
- Not a consumer-facing “AI consciousness” app.
- Not a covert monitoring tool.

## Features included
- identity anchor + session continuity
- role-switch policy gate
- memory write approval flow
- backend router with sovereignty/risk hints
- evidence binding
- white-box report generation
- replay bundle export
- local policy engine with optional OPA hook
- FastAPI endpoints and smoke tests

## Quick start

```bash
cd organization_ai_control_plane_upgrade_kit
python -m venv .venv
source .venv/bin/activate
pip install -e .
python scripts/demo_flow.py
pytest -q
uvicorn src.control_plane.app:app --reload
```

Open docs at:
- http://127.0.0.1:8000/docs

## Production upgrade path
1. Replace SQLite with Postgres.
2. Replace local file artifacts with object storage.
3. Turn on OPA and move hard gates into policy bundles.
4. Add OIDC / SSO.
5. Add OpenTelemetry + log shipping.
6. Deploy on Kubernetes with admission / audit patterns.

## Core opinion
The scarce asset is not "owning the AI"; it is owning the **policy, evidence, approval, replay, and audit surface** around strong models.
