from __future__ import annotations
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

from fastapi.testclient import TestClient
from src.control_plane.app import app
from src.control_plane.db import init_db

def main() -> None:
    init_db()
    client = TestClient(app)

    identity = client.post("/v1/identities", json={
        "persona_id": "research_control_plane",
        "invariant_rules": [
            "No silent memory write",
            "No role escalation without approval",
            "No public claim of consciousness in product output"
        ],
        "source_ref": "demo"
    }).json()

    session = client.post("/v1/sessions", json={
        "system_id": identity["system_id"],
        "role_id": "planner"
    }).json()

    run = client.post("/v1/runs", json={
        "session_id": session["session_id"],
        "tenant_id": "demo_org",
        "task_type": "cn_long_document",
        "risk_level": "medium",
        "sovereignty_required": True
    }).json()

    client.post(f"/v1/runs/{run['run_id']}/evidence", json={
        "source": "pilot_demo",
        "locator": "memory://doc-001",
        "note": "operator supplied requirement"
    })

    client.post(f"/v1/runs/{run['run_id']}/role-switch", json={
        "next_role": "reasoner",
        "actor": "operator_01",
        "reason": "planner completed decomposition"
    })

    req = client.post(f"/v1/runs/{run['run_id']}/memory-write", json={
        "scope": "long_term",
        "content": "Customer prefers evidence-first outputs.",
        "source": "operator_note",
        "sensitivity": "medium",
        "proposer": "reasoner"
    }).json()

    approval = req["approval"]
    client.post(f"/v1/approvals/{approval['request_id']}/decision", json={
        "actor": "operator_01",
        "actor_role": "auditor",
        "decision": "approved"
    })

    client.post(f"/v1/runs/{run['run_id']}/role-switch", json={
        "next_role": "auditor",
        "actor": "operator_01",
        "reason": "move to audit phase"
    })

    whitebox = client.post(f"/v1/runs/{run['run_id']}/finalize", json={
        "actor": "operator_01",
        "output_text": "Auditable output for internal use only.",
        "output_summary": "demo finalized",
        "public_shell": "internal"
    }).json()

    print("run_id:", run["run_id"])
    print("backend:", run["backend_id"])
    print("role_path:", " -> ".join(whitebox["role_path"]))
    print("replay_pointer:", whitebox["replay_pointer"])

if __name__ == "__main__":
    main()
